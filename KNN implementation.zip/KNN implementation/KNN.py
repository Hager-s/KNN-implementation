import pandas as pd
import math
import operator


def readingData():
    training = pd.read_csv('TrainData.txt', header=None).values.tolist()
    testing = pd.read_csv('TestData.txt', header=None).values.tolist()
    return training, testing


def getneighbours(test_sample, training, k):
    distances = list()
    for train_row in range(len(training)):
        distance = euclidean_distance(test_sample, training[train_row])
        distances.append((training[train_row][-1], distance))
    distances.sort(key=operator.itemgetter(1))
    neighbours = list()
    for i in range(k):
        neighbours.append(distances[i][0])
    return neighbours

def euclidean_distance(row1,row2):
    distance=0.0
    for i in range(len(row1)-1):
        distance+=pow((row1[i]-row2[i]),2)
    return math.sqrt(distance)




def predict(neighbours, trainingData):
    classes = {}
    for i in neighbours:
        if i in classes:
            classes[i] += 1
        else:
            classes[i] = 1

    sortedClasses = sorted(classes.items(), key=operator.itemgetter(1), reverse=True)
    return sortedClasses[0][0]
    tied = []
    for i in range(len(sortedClasses)):
        if i == 0:
            tied.append(sortedClasses[i][0])
        elif sortedClasses[i][1] < sortedClasses[i - 1][1]:
            break
        else:
            tied.append(sortedClasses[i][0])

    for i in trainingData:
        if i[-1] in tied:
            return i[-1]


def correct_instances(training,testing,k):
    correct = 0
    for i in range(len(testing)):
        neighbours = getneighbours(testing[i],training,k)
        prediction = predict(neighbours, training)
        print('Actual class: ',testing[i][-1],'\t\t\t\tPredicted class: ',prediction)
        if prediction == testing[i][-1]:
            correct += 1
    return correct

def run():
    training , testing = readingData()
    length = len(testing)
    for k in range(1, 10):
        print('K =', k)
        correct = correct_instances(training,testing,k)
        print('Number of correct instances =', correct)
        print('Total instances =', length)
        print('Accuracy =', correct/length)
        print("---------"*10)

y=run()
